java -jar summary-report.jar input output
